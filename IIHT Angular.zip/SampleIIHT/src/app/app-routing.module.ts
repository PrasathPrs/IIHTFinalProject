import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserloginComponent } from './userlogin/userlogin.component';
import { MainPageComponent } from './main-page/main-page.component';
import { UserSearchComponent } from './user-search/user-search.component';

import { MentorCompletedTrainingsComponent } from './mentor-completed-trainings/mentor-completed-trainings.component';

import { AdminMaintainUserDetailsComponent } from './admin-maintain-user-details/admin-maintain-user-details.component';

import { UsersignupComponent } from './usersignup/usersignup.component';

import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';

const routes: Routes = [

  {
    path: 'login',    component: UserloginComponent
 },
 
 {
  path: '',    component: MainPageComponent
},
{
  path: 'mainpage',    component: MainPageComponent
},
{
path: 'usersignup',    component: UsersignupComponent
},
{
  path: 'mentorsignup',    component: MentorsignupComponent
  },
{
  path: 'usersearch',    component: UserSearchComponent
  },
  
  {
    path: 'mentorcompleted',    component: MentorCompletedTrainingsComponent
    },
    
{
  path: 'adminuserdetails',    component: AdminMaintainUserDetailsComponent
  }
  
    

      

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
