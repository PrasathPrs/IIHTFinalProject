export class UserDetails {
    
    username : String;
   firstname : String;
   lastname : String;
   password : String;
}