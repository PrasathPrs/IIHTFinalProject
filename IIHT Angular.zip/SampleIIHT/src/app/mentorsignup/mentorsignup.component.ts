import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router} from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../User';
import { UserServiceService } from '../user-service.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { Mentor } from '../Mentor';
import { MentorserviceService } from '../mentorservice.service';

@Component({
  selector: 'app-mentorsignup',
  templateUrl: './mentorsignup.component.html',
  styleUrls: ['./mentorsignup.component.css']
})
export class MentorsignupComponent implements OnInit {

   mentordetails : boolean;
   mentortech : boolean;
   mentortime : boolean;
   register : boolean;
  formdata;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  technology = [];
  musername : String;
  // usr:User=new User();

   mntr : Mentor = new Mentor();
  submitted = false;
  
   
   constructor(private router: Router,private mentorService:  MentorserviceService) { }
   ngOnInit() {
      this.mentordetails = true;

      
      this.formdata = new FormGroup({
         uname: new FormControl("", Validators.compose([
            Validators.required,
            Validators.minLength(3)
         ])),
           fname: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         lname: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         cnum: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         exp: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
        
         cpasswd: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         
         passwd: new FormControl("", this.passwordvalidation)
      })
      
   }
   passwordvalidation(formcontrol) {
      if (formcontrol.value.length < 5) {
         return {"passwd" : true};
      }

      
   }

   save() {
      this.musername = this.mntr.username;
      this.mentorService.createMentor(this.mntr)
        .subscribe(data => console.log(data), error => console.log(error));
      this.mntr = new Mentor();
    }

   onClickSubmit(data) {

      this.submitted = true;
      this.save();


      this.mentorService.getAdminTechnologyList().subscribe(data =>{  
         this.dropdownList = data as string[];  
              })

         // this.dropdownList = [
         //    { item_id: 1, item_text: 'Mumbai' },
         //    { item_id: 2, item_text: 'Bangaluru' },
         //    { item_id: 3, item_text: 'Pune' },
         //    { item_id: 4, item_text: 'Navsari' },
         //    { item_id: 5, item_text: 'New Delhi' }
         //  ];
   
          
   
          this.dropdownSettings= {
            singleSelection: false,
            idField: 'id',
            textField: 'technology',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            // itemsShowLimit: 3,
            allowSearchFilter: true
          };

          this.mentortech = true;
          this.mentordetails=false;


   }

   onItemSelect(item: any) {
      this.technology.push(item);
      console.log(item);
    }
    onSelectAll(items: any) {
       this.technology = items;
      console.log(items);
    }


    addTech(){
       for(let i of this.technology)
       {
         this.mentorService.saveTechnology(this.musername,i.technology)
         .subscribe(data => console.log(data), error => console.log(error));
       }

       this.register = true;
       this.mentortech =false;
       this.mentordetails=false;

    }

}
