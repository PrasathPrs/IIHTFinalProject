import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router} from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../User';
import { UserServiceService } from '../user-service.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { Mentor } from '../Mentor';
import { MentorserviceService } from '../mentorservice.service';
import { UserDetails } from '../UserDetails';

@Component({
  selector: 'app-usersignup',
  templateUrl: './usersignup.component.html',
  styleUrls: ['./usersignup.component.css']
})
export class UsersignupComponent implements OnInit {

  formdata;
  usrdt : UserDetails = new UserDetails();
  submitted : boolean;
  userregistration : boolean;
  
   
   constructor(private router: Router,private userService:  UserServiceService) { }
   ngOnInit() {

      this.userregistration=true;
      this.submitted= false;
      
      this.formdata = new FormGroup({
         uname: new FormControl("", Validators.compose([
            Validators.required,
            Validators.minLength(3)
         ])),
           fname: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         lname: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         
         cpasswd: new FormControl("", Validators.compose([
            Validators.required
            // ,Validators.minLength(3)
         ])),
         
         passwd: new FormControl("", this.passwordvalidation)
      })
      
   }
   passwordvalidation(formcontrol) {
      if (formcontrol.value.length < 5) {
         return {"passwd" : true};
      }

      
   }

   save() {
      this.userService.createUser(this.usrdt)
        .subscribe(data => console.log(data), error => console.log(error));
      this.usrdt = new UserDetails();
    }

   onClickSubmit(data) {

      this.save();
      this.submitted = true;
      this.userregistration=false;
      


     


   }

  

   

}
