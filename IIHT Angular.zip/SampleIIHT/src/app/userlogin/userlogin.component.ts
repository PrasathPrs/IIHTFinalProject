import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router} from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../User';
import { UserServiceService } from '../user-service.service';


@Component({
   selector: 'app-userlogin',
   templateUrl: './userlogin.component.html',
   styleUrls: ['./userlogin.component.css']
})

export class UserloginComponent implements OnInit {
   formdata;
   usr:User=new User();
  
   
   constructor(private router: Router,private userService: UserServiceService) { }
   ngOnInit() {
      this.formdata = new FormGroup({
         uname: new FormControl("", Validators.compose([
            Validators.required,
            Validators.minLength(3)
         ])),
         passwd: new FormControl("", this.passwordvalidation)
      });
   }
   passwordvalidation(formcontrol) {
      if (formcontrol.value.length < 5) {
         return {"passwd" : true};
      }
   }
   onClickSubmit(data) {
      // console.log(data.uname);
      // if (data.uname == "systemadmin" && data.passwd == "admin123") {
      //    alert("Login Successful");
      //   this.router.navigate(['usersearch'])
      // }

      this.userService.getUser(data.uname).subscribe(value =>{  
         this.usr = value})  

         if(this.usr.password == data.passwd)
         {

            
            if(this.usr.role.id == 3)
            {
               this.router.navigate(['usersearch',{ id: data.uname}])
            }
            if(this.usr.role.id == 2)
            {
               this.router.navigate(['mentorcompleted',{ id: data.uname}])
            }
            if(this.usr.role.id == 1)
            {
               this.router.navigate(['adminuserdetails'])
            }

            
         }

   }
}

