import { User } from './User';

export class UserCompletedTrainings {
    
    id : number;
    duration : string;
    technology : string;
    //user : User;
    
}