import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MentorserviceService {

  private baseUrl = 'http://localhost:8098/save';  

  constructor(private http: HttpClient) { }

  createMentor(mentor : Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, mentor);
  }

  getAdminTechnologyList(): Observable<any> {
    return this.http.get(`http://localhost:8090/findtechnology`);
  }

  saveTechnology(mentor : String,id : String): Observable<Object> {
    return this.http.post(`http://localhost:8098/savetechnology/${mentor}/${id}`, mentor);
  }


  getMentorCompletedList(username : String): Observable<any> {
    return this.http.get(`http://localhost:8098//findcompleted/${username}`);
  }

  // getMentorCurrentList(username : String): Observable<any> {
  //   return this.http.get(`http://localhost:8098//findcurrent/${username}`);
  // }


  // getAdminTechnologyList(username : String): Observable<any> {
  //   return this.http.get(`http://localhost:8088//findcurrent/${username}`);
  // }

  getMentorCurrentList(username : String): Observable<any> {
    return this.http.get(`http://localhost:8092//findcurrentmentorlist/${username}`);
  }

  addTechnology(tech : string): Observable<any> {
    return this.http.get(`http://localhost:8090/addtechnology/${tech}`);
  }
  
}
