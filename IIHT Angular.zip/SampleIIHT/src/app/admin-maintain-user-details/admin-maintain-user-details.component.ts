import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import { MentorserviceService } from '../mentorservice.service';

@Component({
  selector: 'app-admin-maintain-user-details',
  templateUrl: './admin-maintain-user-details.component.html',
  styleUrls: ['./admin-maintain-user-details.component.css']
})
export class AdminMaintainUserDetailsComponent implements OnInit {

  constructor(private httpservice : HttpClient,private route: ActivatedRoute,private mentorService: MentorserviceService,private userService: UserServiceService) { }

  course : string[];
  bcourse : string[];
  current : string[];
  search : string[];
  username : string;
  usersearch : boolean;
  mentorsearch : boolean;
  edittech : boolean;
  skill : string;
  buser : string;
  ubuser : string;

  i : number;


  searchCourse() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[2];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
  }


  onUserSearch(): void { 
    this.i=0;
   
    this.userService.getUserSearchList().subscribe(data =>{  
      this.course = data as string[];  
           })

    this.userService.getBlockUserList().subscribe(data =>{  
            this.bcourse = data as string[];  
                 })

    this.usersearch = true;
    this.mentorsearch = false;
    this.edittech = false;
  }


  onMentorSearch(): void { 
    this.i=0;

    this.userService.getUserSearchList().subscribe(data =>{  
      this.course = data as string[];  
           })

    this.userService.getBlockUserList().subscribe(data =>{  
            this.bcourse = data as string[];  
                 })
    
    this.usersearch = false;
    this.mentorsearch = true;
    this.edittech =false;
  }

  onAddSkill(): void { 

    // this.mentorService.getMentorCurrentList(this.username).subscribe(data =>{  
    //   this.current = data as string[];  
    //        })

           this.i=0;
    
    this.usersearch = false;
    this.mentorsearch = false;
    this.edittech = true;
  }

  ngOnInit() {

    this.username = this.route.snapshot.paramMap.get('id');

    this.i=0;

    this.userService.getUserSearchList().subscribe(data =>{  
      this.course = data as string[];  
           })

    this.userService.getBlockUserList().subscribe(data =>{  
            this.bcourse = data as string[];  
                 })
    
    // this.getUserCompleted();

    this.usersearch = true;
    this.mentorsearch = false;
    this.edittech = false;

    // this.httpservice.get('../../assets/coursedetails.json').subscribe(

    //       data=>{
    //         this.course = data as string[];
    //       },
    //       (err : HttpErrorResponse) => {
    //         console.log(err.message);
    //       }
    //     )

    
  }


  // proposeTraining(id: number,tech : string) {
  //   this.mentorService.proposeTrain(id,tech,this.username)
  //     .subscribe(data => console.log(data), error => console.log(error));
  // }


  logText(value: string): void {
    this.skill = value;

    this.mentorService.addTechnology(this.skill)
         .subscribe(data => console.log(data), error => console.log(error));

         this.skill='';

  }


  blockUser(value: string): void {
    
    this.buser = value;
    this.userService.blockUserService(this.buser)
         .subscribe(data => console.log(data), error => console.log(error));

         this.ngOnInit();


  }


  unblockUser(value: string): void {


    this.ubuser = value;
    this.userService.unblockUserService(this.ubuser)
         .subscribe(data => console.log(data), error => console.log(error));

         this.ngOnInit();

  }


}
