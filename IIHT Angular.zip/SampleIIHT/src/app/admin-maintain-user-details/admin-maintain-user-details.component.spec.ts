import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMaintainUserDetailsComponent } from './admin-maintain-user-details.component';

describe('AdminMaintainUserDetailsComponent', () => {
  let component: AdminMaintainUserDetailsComponent;
  let fixture: ComponentFixture<AdminMaintainUserDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminMaintainUserDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminMaintainUserDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
