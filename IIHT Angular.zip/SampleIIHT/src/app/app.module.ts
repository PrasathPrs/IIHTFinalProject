import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainPageComponent } from './main-page/main-page.component';

import { UserSearchComponent } from './user-search/user-search.component';

import { MentorCompletedTrainingsComponent } from './mentor-completed-trainings/mentor-completed-trainings.component';

import { AdminMaintainUserDetailsComponent } from './admin-maintain-user-details/admin-maintain-user-details.component';

import { UserloginComponent } from './userlogin/userlogin.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { UsersignupComponent } from './usersignup/usersignup.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';



@NgModule({
  declarations: [
    AppComponent,
    MainPageComponent,
   
    UserSearchComponent,
   
    MentorCompletedTrainingsComponent,
    
    AdminMaintainUserDetailsComponent,
   
    UserloginComponent,
    
    UsersignupComponent,
    MentorsignupComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgMultiSelectDropDownModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
