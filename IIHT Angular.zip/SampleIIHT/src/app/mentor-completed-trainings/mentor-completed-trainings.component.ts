import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import { MentorserviceService } from '../mentorservice.service';

@Component({
  selector: 'app-mentor-completed-trainings',
  templateUrl: './mentor-completed-trainings.component.html',
  styleUrls: ['./mentor-completed-trainings.component.css']
})
export class MentorCompletedTrainingsComponent implements OnInit {

  constructor(private httpservice : HttpClient,private route: ActivatedRoute,private mentorService: MentorserviceService) { }

  course : string[];
  current : string[];
  search : string[];
  username : string;
  usersearch : boolean;
  usercurrent : boolean;
  usercompleted : boolean;
  skill : string;

  i : number;


  searchCourse() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[2];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
  }


  onUserSearch(): void { 
    this.i=0;
   
    // this.mentorService.getMentorCurrentList(this.username).subscribe(data =>{    
    //   this.search = data as string[];  
    //        })

    this.usersearch = true;
    this.usercurrent = false;
    this.usercompleted = false;
  }


  onUserCompleted(): void { 
    this.i=0;
    this.mentorService.getMentorCompletedList(this.username).subscribe(data =>{  
      this.course = data as string[];  
           })
    this.usersearch = false;
    this.usercurrent = false;
    this.usercompleted = true;
  }

  onUserCurrent(): void { 

    this.mentorService.getMentorCurrentList(this.username).subscribe(data =>{  
      this.current = data as string[];  
           })

           this.i=0;
    
    this.usersearch = false;
    this.usercurrent = true;
    this.usercompleted = false;
  }

  ngOnInit() {

    this.username = this.route.snapshot.paramMap.get('id');

    this.usersearch = true;
    
  }


  // proposeTraining(id: number,tech : string) {
  //   this.mentorService.proposeTrain(id,tech,this.username)
  //     .subscribe(data => console.log(data), error => console.log(error));
  // }


  logText(value: string): void {
    this.skill = value;

    this.mentorService.saveTechnology(this.username,this.skill)
         .subscribe(data => console.log(data), error => console.log(error));

         this.skill='';

  }

}
