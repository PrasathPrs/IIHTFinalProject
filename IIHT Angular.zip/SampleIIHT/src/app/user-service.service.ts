import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './User';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  private baseUrl = 'http://localhost:8086';  

  constructor(private http: HttpClient) { }

  getUser(username : String): Observable<any> {
    return this.http.get(`${this.baseUrl}/loginuser/${username}`);
  }

  // createEmployee(employee: Object): Observable<Object> {
  //   return this.http.post('http://localhost:8086/states', employee);
  // }


  getTrainingList(): Observable<any> {
    return this.http.get(`http://localhost:8092//findmentorlist`);
  }

  getUserCompletedList(username : String): Observable<any> {
    return this.http.get(`http://localhost:8086//findcompleted/${username}`);
  }

  getUserCurrentList(username : String): Observable<any> {
    return this.http.get(`http://localhost:8086//findcurrent/${username}`);
  }


  proposeTrain(id : number,tech : String,username : String): Observable<Object> {
    return this.http.get(`http://localhost:8098//proposeTraining/${id}/${tech}/${username}`);
  }

  getUserSearchList(): Observable<any> {
    return this.http.get(`http://localhost:8090//finduser`);
  }


  blockUserService(username : String): Observable<any> {
    return this.http.get(`http://localhost:8090//blockuser/${username}`);
  }

  getBlockUserList(): Observable<any> {
    return this.http.get(`http://localhost:8090//blockuserlist`);
  }

  unblockUserService(username : String): Observable<any> {
    return this.http.get(`http://localhost:8090//unblockuser/${username}`);
  }

  createUser(user : Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/saveUserdetails`, user);
  }


}
